import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {SurveyModel} from "../model/survey";

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http: HttpClient) { }
  URL = "http://localhost:8080/api/survey/"



  vote(option: string): Observable<SurveyModel> {
    return this.http.post<SurveyModel>(this.URL + 'vote/' + option, {})
  }
}
