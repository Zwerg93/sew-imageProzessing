export interface SurveyModel {
  text: string;
  result: Map<string, number>;
}
