import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {HttpService} from "./services/http.service";
import {webSocket, WebSocketSubject} from "rxjs/webSocket";


interface Option {
  name: string;
  value: number;
}


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent implements OnInit {
  title = 'fe';
  // @ts-ignore
  @ViewChild('canvas', {static: true}) canvas: ElementRef<HTMLCanvasElement>;
  private options?: Option[] = [];

  constructor(private http: HttpService) {
  }

  private myWebSocket: WebSocketSubject<any> | undefined;

  data: any;

  private context?: CanvasRenderingContext2D;
  ngOnInit(): void {
    this.myWebSocket = webSocket({
      url: 'ws://localhost:8080/survey-websocket/',
      deserializer: msg => msg.data
    });
    this.myWebSocket.subscribe(value => {
      this.options = []
      //console.log(value)

      this.data = JSON.parse(value);

      // console.log(this.data)

      this.data.result = new Map(Object.entries(this.data.resutMap));

      let test = Array.from(this.data.result.keys())
      let test2 = [...this.data.result]

      for (let i = 0; i < test.length; i++) {


        const obj: Option = {// @ts-ignore
          name: test[i],
          value : test2[i][1],

        }
        // @ts-ignore
        this.options.push(obj)
        console.log(this.options)
       // console.log(test2[i][1])

      }

      // @ts-ignore
      this.context = this.canvas.nativeElement.getContext('2d');
      this.drawBars();

      //this.drawBar(this.data.result.entries().next().value[1])
    })

  }

  drawBars() {

    // @ts-ignore
    this.context.clearRect(0, 0, this.canvas.nativeElement.width, this.canvas.nativeElement.height);
    // @ts-ignore
    this.options.forEach((option, index) => {
      // @ts-ignore
      this.context.fillRect(index * 50, this.canvas.nativeElement.height - option.value, 40, option.value);
      // @ts-ignore
      this.context.fillText(option.name, index * 50, this.canvas.nativeElement.height - option.value - 15);
    });

  }




  drawBar(value: number) {
    const ctx = this.canvas.nativeElement.getContext('2d');
    // Draw a bar based on the value received from the websocket
    ctx!.fillRect(0, 0, value, 100);

  }


  voteFOrOption(i: String) {

    // @ts-ignore
    this.http.vote(i).subscribe((c=>{
      console.log(c)
    }))

  }
}
