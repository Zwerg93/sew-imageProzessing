package ac.at.htl.services;

import ac.at.htl.model.SurveyModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;

public class SurveyEncoder implements Encoder.Text<SurveyModel> {
    ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String encode(SurveyModel survey) throws EncodeException {
        try {
            return objectMapper.writeValueAsString(survey);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void init(EndpointConfig endpointConfig) {

    }

    @Override
    public void destroy() {

    }
}
