package ac.at.htl.api;

import ac.at.htl.model.SurveyModel;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("api/survey")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class SurveyResource {

    @Inject
    SurveyWebSocket surveyWebSocket;

    @POST
    public Response initSurvey(SurveyModel survey) {
        System.out.println(survey.toString());
        this.surveyWebSocket.setSurvey(survey);
        return Response.ok().build();
    }


    @POST
    @Path("/vote/{option}")
    public Response vote(@PathParam("option") String option){
        this.surveyWebSocket.onMessage(option);
        return Response.ok().build();
    }
}
