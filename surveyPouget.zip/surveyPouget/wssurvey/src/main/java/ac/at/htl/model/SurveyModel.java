package ac.at.htl.model;

import java.io.Serializable;
import java.util.HashMap;

public class SurveyModel implements Serializable {

    public String question;

    public HashMap<String, Long> resutMap = new HashMap<>();

    public void vote(String chosen) {
        if (this.resutMap.containsKey(chosen)) {
            this.resutMap.put(chosen, this.resutMap.get(chosen) + 1);
        }
    }

}
