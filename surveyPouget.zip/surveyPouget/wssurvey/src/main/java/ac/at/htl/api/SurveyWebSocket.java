package ac.at.htl.api;


import ac.at.htl.model.SurveyModel;
import ac.at.htl.services.SurveyEncoder;

import javax.enterprise.context.ApplicationScoped;
import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@ServerEndpoint(value = "/survey-websocket/", encoders = SurveyEncoder.class)
@ApplicationScoped
public class SurveyWebSocket {
    List<Session> sessions = new LinkedList<>();

    SurveyModel survey;

    public void setSurvey(SurveyModel survey){
        this.survey = survey;
        this.sessions.clear();
    }

    @OnOpen

    public void onOpen(Session session) {
        System.out.println("Logged in" );

        session.getAsyncRemote().sendObject(this.survey, sendResult -> {
            if (sendResult.isOK()){
                System.out.println("Survey send");
            }else {
                System.out.println("Survey failed");
            }
        });
        this.sessions.add( session);
    }

    @OnClose
    public void onClose(Session session){
        System.out.println("Closed");
        this.sessions.remove(session);
    }

    @OnError
    public void onError(Session session, Throwable throwable) {
        this.sessions.remove(session);
        System.out.println("onError>" + throwable.toString());
    }

    @OnMessage
    public void onMessage(String message) {
        System.out.println(message);
        this.survey.vote(message);
        this.sessions.stream().forEach(this::update);
    }
    public void update(Session session){
        session.getAsyncRemote().sendObject(this.survey, sendResult -> {
            if (sendResult.isOK()){
                System.out.println("OK");
            }else {
                System.out.println("FAIL");
            }
        });
    }


}
